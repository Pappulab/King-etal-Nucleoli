https://chart.imjoy.io/?load=https://gist.githubusercontent.com/oeway/4c83b0d463cdd8d898e94dae74a54ec9

Load data - MUST BE IN .CSV
Then hit +trace and select the x and y
Then color as wanted